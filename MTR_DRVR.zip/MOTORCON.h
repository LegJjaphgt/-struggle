#include <Arduino.h>
//#include "CSTM_FNTN.h"

void MODE_SELECT(MTR_STTS *SLT);

#define SPEED_REV  SLT->SPEED_FLUID = SLT->SPEED + SLT->ACCL_DCL_VAL

#define AC_DECEL(A,B,C)\
\
  SPEED_REV;\
      \
      if((A))\
      {\
        SLT->MODE = (B);\
      }\
    \
      else if(SLT->SPEED_CNT == SLT->ACCL_DCL_TIME)\
      {\
        (C);\
        SLT->SPEED_CNT = 0;\
      }\
    \
  MTR_MV(SLT);   
        
        
        //Serial.println(SLT->ACCL_DCL_VAL);
