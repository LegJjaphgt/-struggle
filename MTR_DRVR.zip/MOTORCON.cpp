#include "CSTM_FNTN.h"
#include "MOTORCON.h"

int a = 0;

void MTR_MV( MTR_STTS *SLT)
{ 
  if (SLT->SPEED_FLUID_CNT++ >= SLT->SPEED_FLUID)
  {
    SLT->SPEED_FLUID_CNT = 0;
    
    if((SLT->MODE == ACCEL)||(SLT->MODE == DECEL))
    {
      SLT->SPEED_CNT++;
    }
    else
    {
      SLT->SPEED_CNT = 0;
    }
    digitalWrite(SLT->STEP, HIGH);
    if(SLT->ROUND_PRSNC == true)
    {
      if(SLT->ROUND_CNT == 0)
      {
        if(SLT->ROUND)
        {
          //Serial.println(SLT->ROUND);
          SLT->ROUND--;
          SLT->ROUND_CNT = ONE_ROUND;
        }
        else
        {
        //Serial.println(SLT->ROUND);  
        SLT->POWER = OFF;
        SLT->ROUND_PRSNC = false;
        SLT->MODE = DECEL;
        
        SLT->ACCL_DCL_VAL++;
        
        return;
        }
      }
      SLT->ROUND_CNT--; 
      //Serial.println(SLT->ROUND_CNT); 
    } 
  }
  else
  {
    digitalWrite(SLT->STEP,LOW);
  }
}

void MODE_SELECT(MTR_STTS *SLT)
{

  switch(SLT->MODE)
  {
    case NONE:
      
      break;
      
    case ACCEL:
      if(digitalRead(SLT->STEP)==HIGH)
      {
      a++;
      Serial.println(a);
      }
      AC_DECEL(SLT->ACCL_DCL_VAL == 0, KEEP, SLT->ACCL_DCL_VAL--)
      
      break;
      
    case KEEP:
      if(digitalRead(SLT->STEP)==HIGH)
      {
      a++;
      Serial.println(a);
      }
      AC_DECEL(0,0,0)
      
      break;
      
    case DECEL:
      if(digitalRead(SLT->STEP)==HIGH)
      {
      a++;
      Serial.println(a);
      }
      AC_DECEL(SLT->ACCL_DCL_VAL > 19, NONE, SLT->ACCL_DCL_VAL++)
      
      break;
  }
}
