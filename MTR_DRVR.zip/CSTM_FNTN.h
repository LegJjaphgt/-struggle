#include <Arduino.h>

//----------------------------------------------------
#define BAUD_RATE  115200

#define M_EN  8

#define X_DIR 5 
#define Y_DIR 6
#define Z_DIR 7

#define X_STEP  2 
#define Y_STEP  3
#define Z_STEP  4

#define ONE_ROUND 1600

#define OUTPUT_PIN(pin) pinMode(pin,OUTPUT)
#define SERIAL_BPS Serial.begin(BAUD_RATE)
//----------------------------------------------------
//----------------------------------------------------
#define ON 1
#define OFF 0

typedef enum 
{
  NONE = 0,
  ACCEL,
  KEEP,
  DECEL
}STATUS;

typedef struct CAL
{
  int AC_DECEL_ROUND_NUM;
  int AC_DECEL_ROUND_VAL;
  int AC_DECEL_ROUND_REMAIN;
}ROUND_CAL;

typedef struct MTR
{
  char AXIS[10];          //이름
  int MODE;               //모드 설정 NONE, ACCEL, KEEP, DECEL
  int POWER;              //ON / OFF
  int ROUND;              //스텝수
  int ROUND_CNT;    
  bool ROUND_PRSNC;       //스텝 설정 유무
  ROUND_CAL RC;
  
  int SPEED;              //스피드
  int SPEED_CNT;          //스피드 카운터
  int SPEED_FLUID;        //구동 스피드
  int SPEED_FLUID_CNT;    //스피드 카운터
  
  int ACCL_DCL_TIME;
  int ACCL_DCL_VAL;
  
  int DIR;
  int STEP;
  
}MTR_STTS;

extern MTR_STTS X;
extern MTR_STTS Y;
