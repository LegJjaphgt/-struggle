#include <Arduino.h>

void AC_DECEL_ROUND_CAL_F(MTR_STTS *SLT);


void Serial_In_Data_Clear();
#define Input_Serial(AXIS)                      \
      \
       sscanf(Main_Buf,"%[^.].%[^_]",Sub1,Sub2);\
                                                \
       if(!(strcmp(Sub1,"ON")))                 \
       {                                        \
          AXIS.POWER = ON;                      \
          Serial.println("POWER = ON");         \
          if(atoi(Sub2))                        \
          {                                     \
            AXIS.ROUND_PRSNC = true;            \
            AXIS.ROUND = atoi(Sub2);            \
                                                \
            Serial.println(AXIS.RC.AC_DECEL_ROUND_VAL);   \
            Serial.println(AXIS.RC.AC_DECEL_ROUND_REMAIN);   \
            if(AXIS.ROUND <= AXIS.RC.AC_DECEL_ROUND_VAL)        \
            {                                   \
              Serial.println(0);   \
              if(AXIS.ROUND%2)\
              {\
                AXIS.ROUND_CNT = ONE_ROUND/2;        \
              }\
              AXIS.ROUND = AXIS.ROUND/2;  \
            }                                   \
            else                                \
            {                                   \
              if(!AXIS.RC.AC_DECEL_ROUND_REMAIN) \
              {\
                AXIS.ROUND = AXIS.ROUND - (AXIS.RC.AC_DECEL_ROUND_VAL/2); \
              }\
              else \
              {\
                AXIS.ROUND = AXIS.ROUND - ((AXIS.RC.AC_DECEL_ROUND_VAL/2)+1); \
                AXIS.ROUND_CNT = ONE_ROUND - (AXIS.RC.AC_DECEL_ROUND_REMAIN/2);\
              }\
            }                                   \
                                                \
            Serial.println(AXIS.ROUND);   \
            Serial.println(AXIS.ROUND_CNT);   \
            Serial.println(AXIS.ROUND_PRSNC);   \
          }                                     \
          else                                  \
          {                                     \
            AXIS.ROUND_PRSNC = false;           \
            AXIS.ROUND = atoi(Sub2);            \
          }\
       }\
       else if(!(strcmp(Sub1,"OFF")))\
       {\
          AXIS.POWER = OFF;\
          Serial.println("POWER = OFF");\
       }\
       else if(!(strcmp(Sub1,"SPD")))\
       {\
          switch(atoi(Sub2))\
          {\
            case 10:\
              AXIS.SPEED = 1;\
            break;\
            case 6:\
              AXIS.SPEED = 2;\
            break;\
            case 5:\
              AXIS.SPEED = 3;\
            break;\
            case 4:\
              AXIS.SPEED = 4;\
            break;\
            case 3:\
              AXIS.SPEED = 5;\
            break;\
            case 2:\
              AXIS.SPEED = 9;\
            break;\
            case 1:\
              AXIS.SPEED = 19;\
            break;\
            default:\
              AXIS.SPEED = 19;\
            break;\
          }\
       }\
       else if(!(strcmp(Sub1,"FLD")))\
       {\
          AXIS.RC = {40,0,0};\
          AXIS.ACCL_DCL_TIME = atoi(Sub2);\
          AC_DECEL_ROUND_CAL_F(&AXIS);\
       }\
       \
       if((AXIS.POWER == ON)||(!(strcmp(Sub0,"ALL_ON"))))\
       {\
          if((AXIS.MODE == NONE)&&(AXIS.MODE != ACCEL))\
          {\
            AXIS.POWER = ON;\
            AXIS.ACCL_DCL_VAL = 19;\
            AXIS.MODE = ACCEL;\
          } \
       }\
       if((AXIS.POWER == OFF)||(!(strcmp(Sub0,"ALL_OFF"))))\
       {\
          if(AXIS.MODE == KEEP)\
          {\
            AXIS.POWER = OFF;\
            AXIS.ACCL_DCL_VAL = 0;\
            AXIS.MODE = DECEL;\
          }\
       }

void Serial_In_Data_Clear();
