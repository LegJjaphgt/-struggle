#include "CSTM_FNTN.h"
#include "Serial.h"


String InString;

void AC_DECEL_ROUND_CAL_F(MTR_STTS *SLT)
{
  while (1)
  {
    if (SLT->RC.AC_DECEL_ROUND_REMAIN < ONE_ROUND)
    {
      if (!SLT->RC.AC_DECEL_ROUND_NUM)
      {
        return;
      }
      SLT->RC.AC_DECEL_ROUND_NUM -= 1;
      SLT->RC.AC_DECEL_ROUND_REMAIN += SLT->ACCL_DCL_TIME;
    }
    else 
    {
      SLT->RC.AC_DECEL_ROUND_VAL += SLT->RC.AC_DECEL_ROUND_REMAIN /ONE_ROUND;
      SLT->RC.AC_DECEL_ROUND_REMAIN = SLT->RC.AC_DECEL_ROUND_REMAIN %ONE_ROUND;
    }
  }
}
 
void Serial_In_Data_Clear()
{
    
    char* Main_Buf  = (char *)malloc(10);
    char* Sub0      = (char *)malloc(10);
    char* Sub1      = (char *)malloc(10);
    char* Sub2      = (char *)malloc(10);
    
    //Serial.write(Serial.read());

    InString = Serial.readStringUntil('\n');

    char RdData[InString.length()+1];
    
    InString.toCharArray(RdData,InString.length()+1);
    
    
    sscanf(RdData,"%[^.].%[^\n]",Sub0,Main_Buf);
    
    Serial.println(RdData);
    
    Serial.print("axis : ");
    Serial.println(Sub0);
    
    if(!(strcmp(Sub0,X.AXIS)))
    { 
       Input_Serial(X)
       if(!(strcmp(Sub1,"STATUS")))
       {
        Serial.println(X.AXIS);
        Serial.println(X.MODE);
        Serial.println(X.POWER);
        Serial.println("X.ROUND");
        Serial.println(X.ROUND);
        Serial.println(X.ROUND_PRSNC);
        Serial.println("X.SPEED");
        Serial.println(X.SPEED);
        Serial.println(X.SPEED_CNT);
        Serial.println(X.SPEED_FLUID);
        Serial.println(X.SPEED_FLUID_CNT);
        Serial.println("X.ACCL_DCL_TIME");
        Serial.println(X.ACCL_DCL_TIME);
        Serial.println(X.DIR);
        Serial.println(X.STEP);
       }
       else
       {
       Serial.print("X.SPEED : ");
       Serial.println(X.SPEED);
       }
    }
    else if(!(strcmp(Sub0,Y.AXIS)))
    { 
       Input_Serial(Y)
       if(!(strcmp(Sub1,"STATUS")))
       {
        Serial.println(Y.AXIS);
        Serial.println(Y.MODE);
        Serial.println(Y.POWER);
        Serial.println("Y.ROUND");
        Serial.println(Y.ROUND);
        Serial.println(Y.ROUND_PRSNC);
        Serial.println("Y.SPEED");
        Serial.println(Y.SPEED);
        Serial.println(Y.SPEED_CNT);
        Serial.println(Y.SPEED_FLUID);
        Serial.println(Y.SPEED_FLUID_CNT);
        Serial.println("Y.ACCL_DCL_TIME");
        Serial.println(Y.ACCL_DCL_TIME);
        Serial.println(Y.DIR);
        Serial.println(Y.STEP);
       }
       else
       {
       Serial.print("Y.SPEED : ");
       Serial.println(Y.SPEED);
       }
    }
    else if(!(strcmp(Sub0,"ALL_ON")))
    { 
      Input_Serial(X)
      Input_Serial(Y)
    }
    else if(!(strcmp(Sub0,"ALL_OFF")))
    { 
      Input_Serial(X)
      Input_Serial(Y)  
    }
    
    free(Main_Buf);
    free(Sub0);
    free(Sub1);
    free(Sub2);
    
    //interrupts();
}
