#include <TimerOne.h>

#include "CSTM_FNTN.h"
#include "Timer.h"

int t_timer_100us = 0,  \
    t_timer_1ms = 0,    \
    t_timer_10ms = 0,   \
    t_timer_100ms = 0,  \
    t_timer_1s = 0;

void t_100us();
void t_1ms();
void t_10ms();
void t_100ms();
void t_1s();

void SCHEDULE()
{
    
      t_100us();
      if(t_timer_100us++ >= 9)
      {
        t_1ms();
        t_timer_100us = 0;
        if(t_timer_1ms++ >= 9)
        {
          t_10ms();
          t_timer_1ms = 0;
          if(t_timer_10ms++ >= 9)
          {
            t_100ms();
            t_timer_10ms = 0;
            if(t_timer_100ms++ >= 9)
            {
              t_1s();
              t_timer_100ms = 0;
              if(t_timer_1s++ >= 9)
              {
                t_timer_1s = 0;
              }
            } 
          }
        } 
      }  
}  

void t_100us()
{
  MODE_SELECT(&X);
  MODE_SELECT(&Y);
  //digitalWrite(X_STEP, !digitalRead(X_STEP));
}
void t_1ms()
{
 
}
void t_10ms()
{

}
void t_100ms()
{
  
}
void t_1s()
{

}  


void TIMER_SET()
{   
    Timer1.initialize(10);
    Timer1.attachInterrupt(SCHEDULE,40);
}
