#include <Arduino.h>
#include "MOTORCON.h"

void TIMER_SET();
void SCHEDULE();
